vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|28 Apr 2008 18:29:19 -0000
vti_extenderversion:SR|5.0.2.2634
vti_cacheddtm:TX|28 Apr 2008 18:29:19 -0000
vti_filesize:IR|1205
vti_backlinkinfo:VX|
