vti_encoding:SR|utf8-nl
vti_author:SR|bbretail
vti_modifiedby:SR|bbretail
vti_timelastmodified:TR|08 May 2008 10:11:52 -0000
vti_timecreated:TR|08 May 2008 10:11:52 -0000
vti_cacheddtm:TX|08 May 2008 10:11:52 -0000
vti_filesize:IR|47033
vti_extenderversion:SR|5.0.2.2634
vti_backlinkinfo:VX|
